# pip install pyzmq cbor keyboard
from zmqRemoteApi_IPv6 import RemoteAPIClient
#from zmqRemoteApi import RemoteAPIClient
import keyboard
import time

#client = RemoteAPIClient('localhost', 23000)
client = RemoteAPIClient('2001:288:6004:17:2023:cdb:5:2', 23000)

print('Program started')
sim = client.getObject('sim')
sim.startSimulation()
print('Simulation started')

def setBubbleRobVelocity(leftWheelVelocity, rightWheelVelocity):
    leftMotor9 = sim.getObject('/leftMotor9')
    rightMotor9 = sim.getObject('/rightMotor9')
    leftMotor10 = sim.getObject('/leftMotor10')
    rightMotor10 = sim.getObject('/rightMotor10')
    sim.setJointTargetVelocity(leftMotor9, leftWheelVelocity)
    sim.setJointTargetVelocity(rightMotor9, rightWheelVelocity)
    sim.setJointTargetVelocity(leftMotor10, leftWheelVelocity)
    sim.setJointTargetVelocity(rightMotor10, rightWheelVelocity)
    
# 使用非阻塞模式
keyboard.unhook_all()

# 設定時間間隔
interval = 0.05

# 初始化移動指令
leftWheelVelocity = 0.0
rightWheelVelocity = 0.0

while True:
    if keyboard.is_pressed('up'):
        leftWheelVelocity = 10.0
        rightWheelVelocity = 10.0
    elif keyboard.is_pressed('down'):
        leftWheelVelocity = -10.0
        rightWheelVelocity = -10.0
    elif keyboard.is_pressed('right'):
        leftWheelVelocity = 10.0
        rightWheelVelocity = -10.0
    elif keyboard.is_pressed('left'):
        leftWheelVelocity = -10.0
        rightWheelVelocity = 10.0
    elif keyboard.is_pressed('q'):
        # stop simulation
        sim.stopSimulation()
        break
    else:
        leftWheelVelocity = 0.0
        rightWheelVelocity = 0.0

    # 發送移動指令
    setBubbleRobVelocity(leftWheelVelocity, rightWheelVelocity)



