# pip install pyzmq cbor keyboard
from zmqRemoteApi_IPv6 import RemoteAPIClient
#from zmqRemoteApi import RemoteAPIClient
import keyboard
import time

#client = RemoteAPIClient('localhost', 23000)
client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')

sim.startSimulation()
print('Simulation started')

def setWaliRobVelocity(leftWheelVelocity, rightWheelVelocity):
    leftMotor3 = sim.getObject('/leftMotor3')
    leftMotor4 = sim.getObject('/leftMotor4')
    rightMotor3 = sim.getObject('/rightMotor3')
    rightMotor4 = sim.getObject('/rightMotor4')
    sim.setJointTargetVelocity(leftMotor3, leftWheelVelocity)
    sim.setJointTargetVelocity(leftMotor4, leftWheelVelocity)
    sim.setJointTargetVelocity(rightMotor3, rightWheelVelocity)
    sim.setJointTargetVelocity(rightMotor4, rightWheelVelocity)

# 使用非阻塞模式
keyboard.unhook_all()

# 設定時間間隔
interval = 0.05

# 初始化移動指令
leftWheelVelocity = 0.0
rightWheelVelocity = 0.0

while True:
    if keyboard.is_pressed('5'):
        leftWheelVelocity = 10.0
        rightWheelVelocity = 10.0
    elif keyboard.is_pressed('8'):
        leftWheelVelocity = -10.0
        rightWheelVelocity = -10.0
    elif keyboard.is_pressed('6'):
        leftWheelVelocity = -2.0
        rightWheelVelocity = 2.0
    elif keyboard.is_pressed('4'):
        leftWheelVelocity = 2.0
        rightWheelVelocity = -2.0
    elif keyboard.is_pressed('q'):
        # stop simulation
        sim.stopSimulation()
        break
    else:
        leftWheelVelocity = 0.0
        rightWheelVelocity = 0.0

    # 發送移動指令
    setWaliRobVelocity(leftWheelVelocity, rightWheelVelocity)

    #