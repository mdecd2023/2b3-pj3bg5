# pip install pyzmq cbor keyboard
from zmqRemoteApi_IPv6 import RemoteAPIClient
#from zmqRemoteApi import RemoteAPIClient
import keyboard
import time

#client = RemoteAPIClient('localhost', 23000)
client = RemoteAPIClient('2001:288:6004:17:2023:cdb:5:2', 23000)

print('Program started')
sim = client.getObject('sim')

sim.startSimulation()
print('Simulation started')

def setWaliRobVelocity(leftWheelVelocity, rightWheelVelocity):
    leftMotor7 = sim.getObject('/leftMotor7')
    leftMotor8 = sim.getObject('/leftMotor8')
    rightMotor7 = sim.getObject('/rightMotor7')
    rightMotor8 = sim.getObject('/rightMotor8')
    sim.setJointTargetVelocity(leftMotor7, leftWheelVelocity)
    sim.setJointTargetVelocity(leftMotor8, leftWheelVelocity)
    sim.setJointTargetVelocity(rightMotor7, rightWheelVelocity)
    sim.setJointTargetVelocity(rightMotor8, rightWheelVelocity)
    
# 使用非阻塞模式
keyboard.unhook_all()

# 設定時間間隔
interval = 0.05

# 初始化移動指令
leftWheelVelocity = 0.0
rightWheelVelocity = 0.0

while True:
    if keyboard.is_pressed('down'):
        leftWheelVelocity = 20.0
        rightWheelVelocity = 20.0
    elif keyboard.is_pressed('up'):
        leftWheelVelocity = -20.0
        rightWheelVelocity = -20.0
    elif keyboard.is_pressed('right'):
        leftWheelVelocity = -5.0
        rightWheelVelocity = 5.0
    elif keyboard.is_pressed('left'):
        leftWheelVelocity = 5.0
        rightWheelVelocity = -5.0
    elif keyboard.is_pressed('q'):
        # stop simulation
        sim.stopSimulation()
        break
    else:
        leftWheelVelocity = 0.0
        rightWheelVelocity = 0.0

    # 發送移動指令
    setWaliRobVelocity(leftWheelVelocity, rightWheelVelocity)

    #

